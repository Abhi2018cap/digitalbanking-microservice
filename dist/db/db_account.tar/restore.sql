--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.0
-- Dumped by pg_dump version 9.6.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.account DROP CONSTRAINT account_customer_id_fkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT pk_custid;
ALTER TABLE ONLY public.account DROP CONSTRAINT pk_accno;
DROP TABLE public.customer;
DROP TABLE public.account;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE account (
    account_no integer NOT NULL,
    customer_id integer,
    ifsc_code character varying(30) NOT NULL,
    account_type character varying(20) NOT NULL,
    account_balance double precision NOT NULL,
    account_creation_date date,
    account_status boolean NOT NULL
);


ALTER TABLE account OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer (
    customer_id integer NOT NULL,
    customer_name character varying(20) NOT NULL,
    password character varying(20),
    last_login date,
    mobile_no integer,
    email_id character varying(50)
);


ALTER TABLE customer OWNER TO postgres;

--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY account (account_no, customer_id, ifsc_code, account_type, account_balance, account_creation_date, account_status) FROM stdin;
\.
COPY account (account_no, customer_id, ifsc_code, account_type, account_balance, account_creation_date, account_status) FROM '$$PATH$$/2126.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer (customer_id, customer_name, password, last_login, mobile_no, email_id) FROM stdin;
\.
COPY customer (customer_id, customer_name, password, last_login, mobile_no, email_id) FROM '$$PATH$$/2125.dat';

--
-- Name: account pk_accno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY account
    ADD CONSTRAINT pk_accno PRIMARY KEY (account_no);


--
-- Name: customer pk_custid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT pk_custid PRIMARY KEY (customer_id);


--
-- Name: account account_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY account
    ADD CONSTRAINT account_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES customer(customer_id);


--
-- PostgreSQL database dump complete
--

