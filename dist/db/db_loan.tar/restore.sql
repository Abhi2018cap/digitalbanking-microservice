--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.0
-- Dumped by pg_dump version 9.6.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.loan DROP CONSTRAINT loan_loanid_fkey;
ALTER TABLE ONLY public.borrower DROP CONSTRAINT loan_loanaccountid_fkey;
ALTER TABLE ONLY public.borrower DROP CONSTRAINT customer_customerid_fkey;
ALTER TABLE ONLY public.loan DROP CONSTRAINT customer_customerid_fkey;
ALTER TABLE ONLY public.loan DROP CONSTRAINT branch_branchid_fkey;
ALTER TABLE ONLY public.loanmaster DROP CONSTRAINT loanmaster_pkey;
ALTER TABLE ONLY public.loan DROP CONSTRAINT loan_pkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_pkey;
ALTER TABLE ONLY public.branch DROP CONSTRAINT branch_pkey;
ALTER TABLE ONLY public.borrower DROP CONSTRAINT borrower_pkey;
DROP TABLE public.loanmaster;
DROP TABLE public.loan;
DROP TABLE public.customer;
DROP TABLE public.branch;
DROP TABLE public.borrower;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: borrower; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE borrower (
    customer_id integer NOT NULL,
    loan_account_id integer NOT NULL
);


ALTER TABLE borrower OWNER TO postgres;

--
-- Name: branch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE branch (
    branch_id integer NOT NULL,
    branch_name character varying(30) NOT NULL,
    ifsc_code character varying(30) NOT NULL,
    branch_city character varying(20) NOT NULL,
    assets double precision NOT NULL
);


ALTER TABLE branch OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE customer (
    customer_id integer NOT NULL,
    customer_name character varying(20) NOT NULL,
    address character varying(20),
    city character varying(20),
    mobile_no integer,
    email_id character varying(50)
);


ALTER TABLE customer OWNER TO postgres;

--
-- Name: loan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE loan (
    loan_account_id integer NOT NULL,
    branch_id integer NOT NULL,
    loan_account_number character varying(20) NOT NULL,
    amount double precision NOT NULL,
    loan_type character varying(3) NOT NULL,
    customer_id integer NOT NULL,
    loan_id integer NOT NULL,
    duration integer NOT NULL,
    rate_of_interest double precision NOT NULL,
    loan_status character varying(10) NOT NULL,
    loan_commencement_date timestamp without time zone,
    loan_creation_date timestamp without time zone,
    loan_emi_date timestamp without time zone
);


ALTER TABLE loan OWNER TO postgres;

--
-- Name: loanmaster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE loanmaster (
    loan_id integer NOT NULL,
    loan_name character varying(20) NOT NULL,
    loan_type character varying(3) NOT NULL
);


ALTER TABLE loanmaster OWNER TO postgres;

--
-- Data for Name: borrower; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY borrower (customer_id, loan_account_id) FROM stdin;
\.
COPY borrower (customer_id, loan_account_id) FROM '$$PATH$$/2151.dat';

--
-- Data for Name: branch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY branch (branch_id, branch_name, ifsc_code, branch_city, assets) FROM stdin;
\.
COPY branch (branch_id, branch_name, ifsc_code, branch_city, assets) FROM '$$PATH$$/2148.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer (customer_id, customer_name, address, city, mobile_no, email_id) FROM stdin;
\.
COPY customer (customer_id, customer_name, address, city, mobile_no, email_id) FROM '$$PATH$$/2149.dat';

--
-- Data for Name: loan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY loan (loan_account_id, branch_id, loan_account_number, amount, loan_type, customer_id, loan_id, duration, rate_of_interest, loan_status, loan_commencement_date, loan_creation_date, loan_emi_date) FROM stdin;
\.
COPY loan (loan_account_id, branch_id, loan_account_number, amount, loan_type, customer_id, loan_id, duration, rate_of_interest, loan_status, loan_commencement_date, loan_creation_date, loan_emi_date) FROM '$$PATH$$/2150.dat';

--
-- Data for Name: loanmaster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY loanmaster (loan_id, loan_name, loan_type) FROM stdin;
\.
COPY loanmaster (loan_id, loan_name, loan_type) FROM '$$PATH$$/2147.dat';

--
-- Name: borrower borrower_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY borrower
    ADD CONSTRAINT borrower_pkey PRIMARY KEY (customer_id, loan_account_id);


--
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (branch_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: loan loan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY loan
    ADD CONSTRAINT loan_pkey PRIMARY KEY (loan_account_id);


--
-- Name: loanmaster loanmaster_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY loanmaster
    ADD CONSTRAINT loanmaster_pkey PRIMARY KEY (loan_id);


--
-- Name: loan branch_branchid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY loan
    ADD CONSTRAINT branch_branchid_fkey FOREIGN KEY (branch_id) REFERENCES branch(branch_id);


--
-- Name: loan customer_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY loan
    ADD CONSTRAINT customer_customerid_fkey FOREIGN KEY (customer_id) REFERENCES customer(customer_id);


--
-- Name: borrower customer_customerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY borrower
    ADD CONSTRAINT customer_customerid_fkey FOREIGN KEY (customer_id) REFERENCES customer(customer_id);


--
-- Name: borrower loan_loanaccountid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY borrower
    ADD CONSTRAINT loan_loanaccountid_fkey FOREIGN KEY (loan_account_id) REFERENCES loan(loan_account_id);


--
-- Name: loan loan_loanid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY loan
    ADD CONSTRAINT loan_loanid_fkey FOREIGN KEY (loan_id) REFERENCES loanmaster(loan_id);


--
-- PostgreSQL database dump complete
--

